package com.cg.atssp.dao;

import com.cg.atssp.dto.TimeSheet;

public interface IAtsspDao {
	
	public Integer timeshetupload(TimeSheet ts);

}
