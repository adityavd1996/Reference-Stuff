package com.cg.atssp.service;

import com.cg.atssp.dto.TimeSheet;

public interface IAtsspService  {
	
	public Integer TimeSheetUpload(TimeSheet ts);
}
