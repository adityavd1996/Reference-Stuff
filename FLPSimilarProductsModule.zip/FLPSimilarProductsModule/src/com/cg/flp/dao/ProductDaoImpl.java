package com.cg.flp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.flp.dto.Merchant_product;
import com.cg.flp.exception.FLPException;




@Repository
public class ProductDaoImpl implements IProductDao {

	@PersistenceContext
	EntityManager entityManager;
	@Override
	public List<Merchant_product> getSimilarProducts(String productCategory) throws FLPException 
	 {
		
		Merchant_product prod=new Merchant_product();
		
		
		
		try {
			 /*prod.setProductCategory("Video Game");
			    prod.setProductName("Mario Advanced");
			    entityManager.persist(prod);*/
			    
			    
			    TypedQuery <Merchant_product> query=entityManager.createQuery("select product from Merchant_product product where product.productCategory = '" + productCategory + "'",Merchant_product.class);
				
			    return query.getResultList(); 
			    /*System.out.println("HI");*/
			    
		       
			    } catch(PersistenceException e)
	            {
		           throw new FLPException(e.getMessage());
	            } 
		        /*finally {
		            entityManager.close();
		        }*/
		
			    
			    //return products;
		
		
		
		}

		
}
	  



