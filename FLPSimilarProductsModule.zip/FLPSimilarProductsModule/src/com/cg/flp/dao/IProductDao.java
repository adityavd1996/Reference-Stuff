package com.cg.flp.dao;

import java.util.List;

import com.cg.flp.dto.Merchant_product;
import com.cg.flp.exception.FLPException;

public interface IProductDao {

  

public List<Merchant_product> getSimilarProducts(String productCategory)throws FLPException;
	
}
