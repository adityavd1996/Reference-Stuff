package com.cg.flp.service;

import java.util.List;

import com.cg.flp.dto.Merchant_product;
import com.cg.flp.exception.FLPException;

public interface IProductService {

	public List<Merchant_product> getSimilarProductsByCategory(/*String productCategory*/) throws FLPException ;
	
	public List<Merchant_product> getSimilarProductsByName(/*String productName*/) throws FLPException ;
	
}
