package com.cg.flp.service;

import java.util.List;

import com.cg.flp.dto.Merchant_product;
import com.cg.flp.exception.FLPException;

public interface IProductService {

	public List<Merchant_product> getSimilarProducts(String productCategory) throws FLPException ;
	
}
