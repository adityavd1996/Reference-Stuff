package com.cg.flp.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.flp.dao.IProductDao;
import com.cg.flp.dto.Merchant_product;
import com.cg.flp.exception.FLPException;



@Service("proService")
@Transactional
public class ProductServiceImpl implements IProductService {

	@Autowired
	IProductDao proDao;
	
	public List<Merchant_product> getSimilarProductsByCategory(/*String productCategory*/) throws FLPException {
		return proDao.getSimilarProductsByCategory(/*productCategory*/);
	}
	
	public List<Merchant_product> getSimilarProductsByName(/*String productName*/) throws FLPException {
		return proDao.getSimilarProductsByName(/*productName*/);
	}
}
