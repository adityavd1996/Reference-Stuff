package com.cg.flp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.flp.dto.Merchant_product;
import com.cg.flp.exception.FLPException;
import com.cg.flp.service.IProductService;




/* *****************************  Auditors Time Sheet Submission Portal **************************************

Author       :  Aditya Vikram Dandapat
Class        :  TimeSheetController
Description  :  Controller Class for connecting the output pages and calling the required functions

*  ***********************************************************************************************************/


	
@Controller
public class ProductController {

	
	@Autowired
	IProductService proService;


	/*@RequestMapping(value="/Home.jsp",method=RequestMethod.GET)
	public String home(){
			return "Home";
			}*/
		
			

	@RequestMapping("/moreSimilarProducts")
	public ModelAndView showSimilarProducts(/*@RequestParam("product_Category")String productCategory,@RequestParam("product_Name")String productName*/)
	{
		ModelAndView mv = new ModelAndView("moreSimilarProducts");
		
	try
	{
		
		List<Merchant_product> prodsbyCategory=proService.getSimilarProductsByCategory(/*productCategory*/);
		
		mv.addObject("productbyCat",prodsbyCategory);	
		
        List<Merchant_product> prodsbyName=proService.getSimilarProductsByName(/*productName*/);
		
		mv.addObject("productbyName",prodsbyName);	
	}
	catch(FLPException ex)
	{
		ex.printStackTrace();
	}

	return mv;
	}
	
	

	
}
