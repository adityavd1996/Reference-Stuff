package com.cg.flp.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity 
@Table(name="merchant_product")
public class Merchant_product {

	    @Id
	    
	    @Column(name="product_Id")
	    private Integer productId;
	    
	    @Column(name="product_Name")
	    private String productName;

	    
	    @Column(name="product_Category")
	    private String productCategory;
	    
	    
	    
	    @Column(name="product_Description")
	    private String productDescription;
	    
	    @Column(name="product_Price")
	    private Double productPrice;
	    
	    @Column(name="product_Image")
	    private String productImage;
	    
	    @Column(name="product_Quantity")
	    private Integer productQuantity;
	    
	    @Column(name="product_Discount")
	    private String productDiscount;
	    
	    private Integer timeForDiscount;
	    
	    @Column(name="product_Promo")
	    private String productPromo;
	    
	    private Integer timeForPromo;
	    
	    private Integer numberOfProductSold;
	    
	    private Double sellingCost;
	    
	    private Double exchangeAmount;
	    
	    @Column(name="merchant_email_Id")
	    private String merhcantEmailId;
	    
	    @Column(name="product_Exchanged")
	    private String productExchanged;
	    
	    
	    public String getProductCategory() {
			return productCategory;
		}

		public void setProductCategory(String productCategory) {
			this.productCategory = productCategory;
		}

		public String getProductName() {
			return productName;
		}

		public void setProductName(String productName) {
			this.productName = productName;
		}

		
		
		public Integer getProductId() {
			return productId;
		}

		public void setProductId(Integer productId) {
			this.productId = productId;
		}

		public String getProductDescription() {
			return productDescription;
		}

		public void setProductDescription(String productDescription) {
			this.productDescription = productDescription;
		}

		public Double getProductPrice() {
			return productPrice;
		}

		public void setProductPrice(Double productPrice) {
			this.productPrice = productPrice;
		}

		public String getProductImage() {
			return productImage;
		}

		public void setProductImage(String productImage) {
			this.productImage = productImage;
		}

		public Integer getProductQuantity() {
			return productQuantity;
		}

		public void setProductQuantity(Integer productQuantity) {
			this.productQuantity = productQuantity;
		}

		public String getProductDiscount() {
			return productDiscount;
		}

		public void setProductDiscount(String productDiscount) {
			this.productDiscount = productDiscount;
		}

		public Integer getTimeForDiscount() {
			return timeForDiscount;
		}

		public void setTimeForDiscount(Integer timeForDiscount) {
			this.timeForDiscount = timeForDiscount;
		}

		public String getProductPromo() {
			return productPromo;
		}

		public void setProductPromo(String productPromo) {
			this.productPromo = productPromo;
		}

		public Integer getTimeForPromo() {
			return timeForPromo;
		}

		public void setTimeForPromo(Integer timeForPromo) {
			this.timeForPromo = timeForPromo;
		}

		public Integer getNumberOfProductSold() {
			return numberOfProductSold;
		}

		public void setNumberOfProductSold(Integer numberOfProductSold) {
			this.numberOfProductSold = numberOfProductSold;
		}

		public Double getSellingCost() {
			return sellingCost;
		}

		public void setSellingCost(Double sellingCost) {
			this.sellingCost = sellingCost;
		}

		public Double getExchangeAmount() {
			return exchangeAmount;
		}

		public void setExchangeAmount(Double exchangeAmount) {
			this.exchangeAmount = exchangeAmount;
		}

		public String getMerhcantEmailId() {
			return merhcantEmailId;
		}

		public void setMerhcantEmailId(String merhcantEmailId) {
			this.merhcantEmailId = merhcantEmailId;
		}

		public String getProductExchanged() {
			return productExchanged;
		}

		public void setProductExchanged(String productExchanged) {
			this.productExchanged = productExchanged;
		}

		@Override
		public String toString() {
			return "Product [productCategory=" + productCategory
					+ ", productName=" + productName + "]";
		}
		
	    
		
		
		
		
	    
	
	
	
}
