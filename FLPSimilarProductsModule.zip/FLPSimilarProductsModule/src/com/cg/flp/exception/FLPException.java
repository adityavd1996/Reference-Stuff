package com.cg.flp.exception;

public class FLPException extends Exception {
	
	public FLPException()
	{
		
	}
	
	public FLPException(String msg)
	{
		super(msg);
	}

	@Override
	public String toString() {
		return "FLPException []";
	}

	

}
