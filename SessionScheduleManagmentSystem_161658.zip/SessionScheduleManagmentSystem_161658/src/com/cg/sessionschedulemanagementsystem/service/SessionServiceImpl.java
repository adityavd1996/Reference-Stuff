package com.cg.sessionschedulemanagementsystem.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.sessionschedulemanagementsystem.beans.NewUser;
import com.cg.sessionschedulemanagementsystem.dao.ISessionDao;


@Service("servicedao")
@Transactional
public class SessionServiceImpl  implements ISessionService{

	@Autowired
	ISessionDao sessiondao;

	//------------------------ 1. Session Schedule Management System --------------------------
			/*******************************************************************************************************
			 - Function Name	:	getSessionSchedule()
			 - Input Parameters	:	
			 - Author			:	CAPGEMINI
			 - Return Type		:	List
			 - Creation Date	:	11/01/2018
			 - Description		:	Retrieving from dao and sending to controller because this method is called in controller
			 ********************************************************************************************************/
	
	@Override
	public List<NewUser> getSessionSchedule() {
		
		List<NewUser> mylist=sessiondao.getSessionSchedule();
		
		return mylist;
	}
}
