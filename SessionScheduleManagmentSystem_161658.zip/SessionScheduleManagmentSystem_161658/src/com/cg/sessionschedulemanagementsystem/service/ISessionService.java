package com.cg.sessionschedulemanagementsystem.service;

import java.util.List;

import com.cg.sessionschedulemanagementsystem.beans.NewUser;

public interface ISessionService {
	
	public List<NewUser> getSessionSchedule();

	
	
}
