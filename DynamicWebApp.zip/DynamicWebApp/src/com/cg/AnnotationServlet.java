package com.cg;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AnnotationServlet
 */
@WebServlet(urlPatterns={"/AnnotationServlet","/Hello"},
initParams={@WebInitParam(name="user",value="Aditya"),@WebInitParam(name="company",value="Capgemini")},loadOnStartup=1)

public class AnnotationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AnnotationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
    
    /**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	   response.setContentType("text/html");
	   PrintWriter out=response.getWriter();
	   ServletConfig c=getServletConfig();
	   String name=c.getInitParameter("user");
	   String loc=c.getInitParameter("company");
	   
	   ServletContext context=getServletContext();
	   String p1=context.getInitParameter("param1");
	   String p2=context.getInitParameter("param2");
	   String p3=context.getInitParameter("param3");
	   String p4=context.getInitParameter("param4");
	   String p5=context.getInitParameter("param5");
	   
	   out.println(" <h3>Namaste !!</h3>  <br> " + name +",  <br>  You are from <br>  " + loc);
	   out.println("<hr>");
	   out.println("<br> <h3>Context Parameters Testing !!...</h3> <br>  " + p1 +", <br>   Second context value passed  <br>" + p2);
	
	   out.println("<hr>");
	   out.println("<br> <h3>Context Parameters with <b>Listener</b> Testing !!...</h3> <br>  " + p3 +",  <br>  Second context value passed  <br>" + p4 +",  <br>  Thrid context value passed  <br>" +p5);
	   
	
	}

	
	
	
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
