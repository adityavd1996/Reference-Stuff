package com.cg;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
//the below annotation.WebListener is important for connecting the passed values from one context to the another context
import javax.servlet.annotation.WebListener;

//Put @WebListener
@WebListener
public class MyListener implements ServletContextListener{

	@Override
	public void contextInitialized(ServletContextEvent arg0) {
		//for getting the servlet context
		ServletContext ctx=arg0.getServletContext();
		ctx.setInitParameter("param3", "France");
		ctx.setInitParameter("param4", "Brazil");
		ctx.setInitParameter("param5", "Tokyo Ghoul");
		
	  
	}
	
	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
	
	}

	


}
