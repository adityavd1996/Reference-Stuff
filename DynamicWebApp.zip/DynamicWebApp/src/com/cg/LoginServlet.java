package com.cg;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet(urlPatterns="/LoginServlet",initParams={@WebInitParam(name="user",value="Aditya"),
		@WebInitParam(name="password",value="abcde")}
      )
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String userName=request.getParameter("username");
		String pwd=request.getParameter("pwd");
		String u=getServletConfig().getInitParameter("user");
		String p=getServletConfig().getInitParameter("password");
		
		if(userName.equals(u) && pwd.equals(p))
		{
			
			
				//URL Retriever method
				out.println("<h1>Welcome "+userName+"</h1>");
				out.println("<a href='GreetServlet?user="+userName+"'><button>Greet</button></a>");
				
				
				
				
				
				
				//Hidden Form
				/*out.println("<form method='post' action='GreetServlet'>");
				
				out.println("<input type='hidden' value='"+ userName + "' name='user'/>");   //Main Step for appending the value of the username in the form
				
				out.println("<input type='submit' value='Greet'/>");
				out.println("</form>");*/
				
				
		
		
		
		}
		else{
			//response.sendRedirect("error.html");
			ServletContext context=getServletContext();
			RequestDispatcher rd=context.getRequestDispatcher("/error.html");
			
			rd.forward(request, response);
			     
		
		}
	
	}

}
