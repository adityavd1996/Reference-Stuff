package com.cg.Employee.service;

import java.util.List;

import com.cg.Employee.exception.EmployeeException;
import com.cg.enployee.dto.Employee;

public interface EmployeeService {

	List<Employee> getEmployees() throws EmployeeException;  
	
}
