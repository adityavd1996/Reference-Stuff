package com.cg.Employee.service;

import java.util.List;

import com.cg.Employee.dao.EmployeeDao;
import com.cg.Employee.dao.EmployeeDaoImpl;
import com.cg.Employee.exception.EmployeeException;
import com.cg.enployee.dto.Employee;

public class EmployeeServiceImpl implements EmployeeService {

	
	EmployeeDao dao=new EmployeeDaoImpl();
	
	
	@Override
	public List<Employee> getEmployees() throws EmployeeException {
		
		return dao.getEmployees();
	}

	
	
}
