package com.cg.Employee.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.Employee.exception.EmployeeException;
import com.cg.Employee.util.DBUtil;
import com.cg.enployee.dto.Employee;

public class EmployeeDaoImpl implements EmployeeDao {

	@Override
	public List<Employee> getEmployees() throws EmployeeException {
		Connection con=DBUtil.getConnection();
		List<Employee> employees=new ArrayList<Employee>();
		try{
			Statement stat=con.createStatement();
			ResultSet rs=stat.executeQuery("select * from employee");
		while(rs.next())
		{
			Employee emp=new Employee();
			emp.setId(rs.getInt(1));
			emp.setName(rs.getString(2));
			emp.setAge(rs.getInt(3));
			emp.setGender(rs.getString(4));
			emp.setSalary(rs.getDouble(5));
			employees.add(emp);
			
		}
		   }catch(SQLException e)
		{
			throw new EmployeeException(e.getMessage());
		}
	
		return employees;
	
	}

	
}
