package com.cg.Employee.dao;

import java.util.List;

import com.cg.Employee.exception.EmployeeException;
import com.cg.enployee.dto.Employee;

public interface EmployeeDao {

	List<Employee> getEmployees() throws EmployeeException;  
	
}
