package com.cg.Employee.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.Employee.exception.EmployeeException;
import com.cg.Employee.service.EmployeeService;
import com.cg.Employee.service.EmployeeServiceImpl;
import com.cg.enployee.dto.Employee;

/**
 * Servlet implementation class EmployeeController
 */
@WebServlet("/EmployeeController")
public class EmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	EmployeeService service=new EmployeeServiceImpl();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<h1>Employees</h1>");
		HttpSession ses=request.getSession();
		
		try {
			List<Employee> employees=service.getEmployees();
		
		RequestDispatcher rd=
			             request.getRequestDispatcher("SuccessServlet");
		request.setAttribute("employees",employees);
		
		//************* method 1 **********************
		
		//rd.forward(request, response);         a requests b and then b requests c and at last c then responds back to a directly        
		//rd.include(request, response);  //request from a to b then b requests c and the c gives response to b and finally b responds to a
		//response.sendRedirect("SuccessServlet");  //it redirects to the connected servlet and checks for the data to be fetched inside that target servlet
		
		//********************   method 2  ***********************
		
		ses.setAttribute("employees", employees); //each user will get their separate sessions
		response.sendRedirect("SuccessServlet");  //it redirects to the connected servlet and checks for the data to be fetched inside that target servlet
		
		
		} catch (EmployeeException e) {
			/*RequestDispatcher rd=request.getRequestDispatcher("ErrorServlet");
			request.setAttribute("error",e);
			
			
			rd.forward(request, response);*/
			response.sendRedirect("SuccessServlet");
		}
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		doGet(request,response);
	}

}
