package com.cap.jpa.dao;

import com.cap.jpa.model.TestBean;

public interface ITestdao {
	
	TestBean findqueryID(Integer queryID);


	boolean textarea(Integer queryID, String textarea);

}
